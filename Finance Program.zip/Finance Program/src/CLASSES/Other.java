package CLASSES;

public class Other extends Category {
	private String Type;

	public void setType(String Type) {
		this.Type = Type;

	}

	public String getType() {
		return Type;
	}
}
