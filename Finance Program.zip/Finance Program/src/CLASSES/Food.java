package CLASSES;

import java.util.Date;

public class Food extends Category {

	private String Place;

	public void setPlace(String Place) {
		this.Place = Place;
	}

	public String getPlace() {
		return Place;
	}
}
