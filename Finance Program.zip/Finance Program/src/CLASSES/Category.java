package CLASSES;
import java.util.Date;

public class Category {
	private Date date;
	private double price;
	private String description;
	
	public Category() {
		date=new Date();
	}
	
	public Date getdate() {
		return date;
	}

	public void setPrice(double price) {
		this.price = price;

	}

	public double getPrice() {
		return price;
	}

	public void setDescription(String description) {
		this.description = description;

	}

	public String getDescriptioin() {
		return description;
	}

}
