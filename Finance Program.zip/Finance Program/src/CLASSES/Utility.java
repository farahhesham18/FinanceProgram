package CLASSES;
import java.util.Date;

public class Utility extends Category {
	private String UtilityType;
	private Date DateBill;

	public Date getdate() {
		return DateBill;
	}

	public void setType(String UtilityType) {
		this.UtilityType = UtilityType;

	}

	public String getType() {
		return UtilityType;
	}
}
