
package CLASSES;  
import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UserDB{

	// create table account in db
	// pk ->email
	// create connection variable
	Connection con;
	Statement stat;
	PreparedStatement pstat;
	
	public UserDB() {
		try {
			// 1) load driver bta3 el db
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			// 2) connect to database
			con = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=FinanceDB", "db", "db1234");
			// 3) excute/run sql statements

			stat = con.createStatement();
			// create table
			 stat.executeUpdate("create table users(id integer identity(100,1) ,address varchar(25), fName varchar(25), lName varchar(25),phoneNumber varchar(25),email varchar(25),password varchar(25), primary key(email))");
			// stat.executeUpdate("create table food( description varchar(25),price
			// varchar(15),date Date,place varchar(50))");
			// stat.executeUpdate("create table transportation( description
			// varchar(25),price varchar(15),date Date ,method varchar(50))");
			// stat.executeUpdate("create table other(pid varchar(20), email varchar(30),
			// pdate Date, ptype varchar(20), primary key (pid))");
			// stat.executeUpdate("create table utilties(pid varchar(20), email varchar(30),
			// pdate Date, ptype varchar(20),primary key (pid))");

		} catch (ClassNotFoundException ex) {
			Logger.getLogger(UserDB.class.getName()).log(Level.SEVERE, null, ex);
		} catch (SQLException ex) {
			Logger.getLogger(UserDB.class.getName()).log(Level.SEVERE, null, ex);
		} finally {
			try {
				con.close();
			} catch (SQLException ex) {
				Logger.getLogger(UserDB.class.getName()).log(Level.SEVERE, null, ex);
			}
		}
	}

	// method insert
	// insert data in table
	public void insertAccount(Person p) {
		try {
			con = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=FinanceDB", "db", "db1234");

			pstat = con.prepareStatement("insert into users values(?,?,?,?,?,?)");
			pstat.setString(1, p.getAddress());
			pstat.setString(2, p.getfName());
			pstat.setString(3, p.getlName());
			pstat.setString(4, p.getPhoneNumber());
			pstat.setString(5, p.getEmail());
			pstat.setString(6, p.getPassword());

			pstat.executeUpdate();
		} catch (SQLException ex) {
			Logger.getLogger(UserDB.class.getName()).log(Level.SEVERE, null, ex);

		} finally {
			try {
				con.close();
			} catch (SQLException ex) {
				Logger.getLogger(UserDB.class.getName()).log(Level.SEVERE, null, ex);
			}
		}

	}

	// delete record from table
	public void delete(Person p) {
		try {
			con = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=FinanceDB", "db", "db1234");

			pstat = con.prepareStatement("delete from users where email=?");
			pstat.setString(1, p.getEmail());

			pstat.executeUpdate();
		} catch (SQLException ex) {
			Logger.getLogger(UserDB.class.getName()).log(Level.SEVERE, null, ex);
		}finally {
			try {
				con.close();
			} catch (SQLException ex) {
				Logger.getLogger(UserDB.class.getName()).log(Level.SEVERE, null, ex);
			}
		}

	}

	//found method
	public boolean found(String s) {
		try {
			con = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=FinanceDB", "db", "db1234");
			stat = con.createStatement();
			ResultSet res = stat.executeQuery("select email from users");
			while (res.next()) {
				if(res.getString(1).equals(s)) {
					return true;
				}
			}
			return false;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}finally {
			try {
				con.close();
			} catch (SQLException ex) {
				Logger.getLogger(UserDB.class.getName()).log(Level.SEVERE, null, ex);
			}
		}
	}
	
	
	public Person getUser(String s) {
		Person p=new Person();
		try {
			con = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=FinanceDB", "db", "db1234");
			stat = con.createStatement();
			ResultSet res = stat.executeQuery("select * from users");
			while(res.next()) {
				if(res.getString("email").equals(s)) {
					p.setEmail(res.getString("email"));
					p.setAddress(res.getString("address"));
					p.setfName(res.getString("fName"));
					p.setlName(res.getString("lName"));
					p.setPassword(res.getString("password"));
					p.setPhoneNumber(res.getString("phoneNumber"));
					p.setId(Integer.parseInt(res.getString("id")));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return p;
	}
	
	
	
	//printing data method
	public void print() {

		try {
			con = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=FinanceDB", "db", "db1234");
			stat = con.createStatement();
			// select * statements from table
			ResultSet res = stat.executeQuery("select * from users");
			while (res.next()) {
				System.out.print("address: " + res.getString("address"));
				System.out.print("   ");
				System.out.print("fName : " + res.getString("fName"));
				System.out.print("   ");
				System.out.print("lName: " + res.getString("lName"));
				System.out.print("   ");
				System.out.print("phoneNumber :" + res.getString("phoneNumber"));
				System.out.print("   ");
				System.out.print("email: " + res.getString("email"));
				System.out.print("   ");
				System.out.println("password : " + res.getString("password"));
				System.out.println("");

			}

		} catch (SQLException ex) {
			Logger.getLogger(UserDB.class.getName()).log(Level.SEVERE, null, ex);
		}finally {
			try {
				con.close();
			} catch (SQLException ex) {
				Logger.getLogger(UserDB.class.getName()).log(Level.SEVERE, null, ex);
			}
		}
	}
/*
	public static void main(String[] args) {

		UserDB u = new UserDB();
		Person p1 = new Person();
		p1.setEmail("salma@44");
		p1.setfName("salma");
		p1.setlName("Ashraf");
		p1.setPhoneNumber("0658888");
		Person p2 = new Person();
		p2.setEmail("juh@fgdd5");
		p2.setfName("faraah");
		p2.setlName("heshaaam");
		p2.setPhoneNumber("0658888");
		
		u.insertAccount(p1);
		u.insertAccount(p2);

		u.print();
		u.delete(p2);
		System.out.println("deleting data!!!\n");
		u.print();

	}
	*/
}
