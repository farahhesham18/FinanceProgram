package CLASSES;

public class Transportation extends Category{
	private String Method;
	private String carFinance;

	public void setMethod(String Method) {
		this.Method = Method;

	}

	public String getMethod() {
		return Method;
	}

	public String getCarFinance() {
		return carFinance;
	}

	public void setCarFinance(String carFinance) {
		this.carFinance = carFinance;
	}
}
